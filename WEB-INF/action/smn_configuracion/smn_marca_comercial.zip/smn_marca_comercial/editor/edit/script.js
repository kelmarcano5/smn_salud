document.form1.mac_codigo.value='${fld:mac_codigo@#,###,###}';
document.form1.mac_descripcion.value='${fld:mac_descripcion@#,###,###}';
document.form1.id.value='${fld:smn_marca_comercial_id@#,###,###}';
 
document.getElementById("formTitle").innerHTML = "${lbl:b_edit_record}";
document.getElementById("grabar").disabled=false;
setFocusOnForm("form1");


document.form1.mac_codigo.disabled=true;
 


document.form1.mac_codigo.disabled=true;
 

