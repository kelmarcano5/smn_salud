select ${seq:nextval@smn_salud.seq_smn_marca_comercial} as id
