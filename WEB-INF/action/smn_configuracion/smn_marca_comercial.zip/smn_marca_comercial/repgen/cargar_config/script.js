setConfiguration('${fld:cfg_descripcion}');

