select
	${field}
from
	smn_salud.smn_marca_comercial
where
		smn_salud.smn_marca_comercial.smn_marca_comercial_id = ${fld:id}
	
