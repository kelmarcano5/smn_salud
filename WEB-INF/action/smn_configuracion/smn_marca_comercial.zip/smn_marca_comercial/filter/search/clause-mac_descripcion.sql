 and
 	smn_salud.smn_marca_comercial.mac_descripcion=${fld:mac_descripcion}