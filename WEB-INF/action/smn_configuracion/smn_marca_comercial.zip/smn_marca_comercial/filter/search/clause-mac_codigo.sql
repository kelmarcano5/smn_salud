 and
 	smn_salud.smn_marca_comercial.mac_codigo=${fld:mac_codigo}