 and
 	smn_salud.smn_marca_comercial.mac_fecha_registro>=${fld:mac_fecha_registro_ini}