addNew();
alertBox ('${lbl:b_record_added}: ${fld:mensaje_id2}', '${lbl:b_continue_button}', null, 'setFocusOnForm("form1");');

